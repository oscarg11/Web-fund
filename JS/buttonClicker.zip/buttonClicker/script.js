// changes login button's text from "login" to "logout"
function logOut(button) {
    button.innerText = "Logout";
}

//removes the "add definition" button
function hide(button) {
    button.remove();
}